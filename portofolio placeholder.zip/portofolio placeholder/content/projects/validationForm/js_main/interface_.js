
inputZero = document.getElementsByClassName('input_control')[0];
inputOne = document.getElementsByClassName('input_control')[1];
inputTwo = document.getElementsByClassName('input_control')[2];






inputZero.addEventListener('focus', () => {inputZero.style.borderRadius ='30px', inputZero.style.boxShadow ='8px 13px 21px #fccb7185';});
inputZero.addEventListener('blur', () => {inputZero.style.borderRadius ='0%', inputZero.style.boxShadow ='0 0 0';});


inputOne.addEventListener('focus', () => {inputOne.style.borderRadius ='30px', inputOne.style.boxShadow ='8px 13px 21px #fccb7185';})
inputOne.addEventListener('blur', () => {inputOne.style.borderRadius ='0%', inputOne.style.boxShadow ='0 0 0';})

inputTwo.addEventListener('focus', () => {inputTwo.style.borderRadius ='30px', inputTwo.style.boxShadow ='8px 13px 21px #fccb7185';})
inputTwo.addEventListener('blur', () => {inputTwo.style.borderRadius ='0%', inputTwo.style.boxShadow ='0 0 0';})


