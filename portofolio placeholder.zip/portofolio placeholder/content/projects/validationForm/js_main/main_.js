

function name_validation(){ 
    
    input = document.getElementById("name").value; 
    letters =  /^[A-Za-z\s]+$/;  
    
    

    
    if(input.match(letters)){ 
    {
    document.getElementById("name").style.background = "green"; 
    }
        
    }


    else if(input == ''){
        document.getElementById("name").style.background = "white";

    }

    else{
        document.getElementById("name").style.background = "red";
    }


    
}
    

function email_validation(){ 

    input = document.getElementById("email").value;
    


    validation1 = /^[^\s@]+@/;


    validation = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    

    if(input.match(validation)){

        document.getElementById("email").style.background = "green";
    }

    else if(input == ''){
        document.getElementById("email").style.background = "white";
    }

    else if(input.match(validation1)){

        document.getElementById('email').style.backgroundColor = '#fccb7185';
    }

    else{
        document.getElementById("email").style.background = "red";
    }
}
    

function card_validation(){ 
    let raw_input = document.getElementById('card').value; 



    function filteringStageOne(){ 
        filteredString_input = String(raw_input).split(' ').join('');  
        filteredString_array = filteredString_input.split('');    

        int_input = [];
        symbols = /[^\p{L}\d\s@#]/u;

        
        if(raw_input.toLowerCase() == raw_input.toUpperCase() && raw_input != '' ){
            document.getElementById('card').style.backgroundColor = '#fccb7185';
            
            
            if (filteredString_array.length == 16){ 

                for(i = 0; i < filteredString_array.length; i = i + 1){

                    if(Number.isInteger(Number(filteredString_array[i])) == true){

                        int_input.push(Number(filteredString_array[i]));
                        
                        
                    }


                
                }

                if (int_input.length !== 16){ 

                    return document.getElementById('card').style.backgroundColor = 'red';

                }


                else{

                    document.getElementById('card').style.backgroundColor = 'yellow';
                    let int_array = [String(int_input[0]) + String(int_input[1]) + String(int_input[2]) + String(int_input[3])+ '  ' 
                    + String(int_input[4]) + String(int_input[5]) + String(int_input[6]) + String(int_input[7]) + '  '+
                    String(int_input[8]) + String(int_input[9]) + String(int_input[10]) + String(int_input[11]) + '  ' + String(int_input[12]) + String(int_input[13]) + String(int_input[14]) + String(int_input[15])];


                    document.getElementById('card').value = int_array;
                }

            }

            else if (filteredString_array.length > 16 || int_input.length > 16 || document.getElementById('card').value.match(symbols) || document.getElementById('card').value.match('@') ){return document.getElementById('card').style.backgroundColor = 'red'};
            
            
        

        }

        else if (raw_input == ''){
            document.getElementById('card').style.backgroundColor = 'white';

        }

        else{return document.getElementById('card').style.backgroundColor = 'red'}


    }


    filteringStageOne();

    function filteringStageTwo(){

        evenNumbers = [];
        oddNumbers = [];
        evenNumbersArray = [];
        evenNumbers_ = 0;
        evenNumbers_sum = 0;
        oddNumbers_sum = 0;


        takingDigits = (number)=> {
            evenNumbers_  = number.toString().split('');
            
        }

        for(let i = 0; i < int_input.length; i = i + 2){
            evenNumbers.push(int_input[i] * 2);
            oddNumbers.push(int_input[i-1]);
        }

        oddNumbers.push(int_input[15]);
        oddNumbers.splice(0,1);

        for(let i = 0; i < evenNumbers.length; i = i + 1){ 

            if (evenNumbers[i] > 9 && evenNumbers[i] < 100){

                takingDigits(evenNumbers[i]);

                for(let i = 0; i < evenNumbers_.length; i = i + 1){
                    evenNumbersArray.push(evenNumbers_[i]);
                }
            }


            else{evenNumbersArray.push(evenNumbers[i])}
        }

        

        for(let i = 0; i < evenNumbersArray.length; i = i + 1){ 

            evenNumbers_sum = evenNumbers_sum + Number(evenNumbersArray[i]);
           
        }

        for(let i = 0; i < oddNumbers.length; i = i + 1){ 

            oddNumbers_sum = oddNumbers_sum + Number(oddNumbers[i]);
           
        }


    }

    filteringStageTwo();


    function filteringStageThree(){

        total_sum = 0
        
        total_sum = oddNumbers_sum + evenNumbers_sum;

        if (total_sum % 10 == 0 && int_input.length == 16){ 

            document.getElementById('card').style.backgroundColor = 'green';

        }

        else if (total_sum % 10 != 0 && int_input.length == 16) {document.getElementById('card').style.backgroundColor = 'red';}

    }

    filteringStageThree()
    

}




function submit_test(){ 

    greenName = document.getElementById('name');
    greenEmail = document.getElementById('email');
    greenCard = document.getElementById('card'); 
    submitButton = document.getElementById('submitBtn');
    buttonSpan = document.getElementById('buttonSpan');
    code = document.getElementsByTagName('code')[0];


    submitButton.addEventListener('click' ,()=>{

        if(greenName.style.backgroundColor == 'green' && greenEmail.style.backgroundColor == 'green' && greenCard.style.backgroundColor == 'green'){ 


            buttonSpan.innerHTML = 'pass';
            buttonSpan.style.color = 'green';
            code.style.backgroundColor = '#4e1b01fa'
        }

        else{ buttonSpan.innerHTML = 'fail'; buttonSpan.style.color = 'red'; code.style.backgroundColor = '#4e1b01fa'};


    })



}


submit_test();




