const fname = document.getElementById('fname');
const lname = document.getElementById('lname');
const email = document.getElementById('email');
const company = document.getElementById('company');
const message_ = document.getElementById('message');

const form_container = document.getElementsByClassName('form')[0];







let emailBody = `

    <b>Name: </b>${fname.value}&nbsp;${lname.value}
    <br>
    <b>Email: </b>${email.value}
    <br> 
    <b>Company: </b>${company.value}
    <br>
    <b>Message: </b>${message_.value}
    <b><br>
`



Email.send({
    SecureToken : "3de46b2e-8bd0-4c66-b5b8-087d5c73e37a",
    To : 'alexalexa982@gmail.com',
    From : 'alexalexa982@gmail.com',
    Subject : 'Someone Contacted You!',
    Body : emailBody
}).then(
  message => alert(message)
);



