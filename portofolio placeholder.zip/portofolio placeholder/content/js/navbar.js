


//creating a toggle function for the hamburger menu

let hamburgerButton = document.getElementsByClassName('hamburger-button')[0];
let navbar = document.getElementsByClassName('navbar')[0];
let navlinks = document.getElementsByClassName('nav_links')[0];

hamburgerButton.addEventListener('click', navbarCustomization);
hamburgerButton.addEventListener('click', ()=> {navlinks.classList.toggle('nav_linksActive')});


function navbarCustomization(){
    navbar.classList.toggle('navbarActive');

    if (navbar.classList[1] == 'navbarActive'){ 
        document.body.style.overflowY = 'hidden';
        
    }else{ 

        document.body.style.overflowY = 'scroll';
    }

}






window.addEventListener('scroll', scrollAble);
window.addEventListener('scroll', hidingNavStyles);


//scrollable function
let previousScroll = scrollY;

function scrollAble(){
    navbar.style.removeProperty('height');
    let currentScroll = scrollY;
    if (previousScroll > currentScroll && navbar.classList[1] !== 'navbarActive'){
        navbar.style.position = 'sticky',
        navbar.style.overflowX = 'clip';
        navbar.style.top = ('0px');
    
    }else if(previousScroll < currentScroll && navbar.classList[1] !== 'navbarActive'){ 
        navbar.style.position = 'sticky',
        navbar.style.overflowX = 'clip';
        navbar.style.top = ('-5.563rem');
    }

    
   previousScroll = currentScroll;
}

function hidingNavStyles(){ 
    navbar.style.removeProperty('height');

    let animationScroll = scrollY;


    if (animationScroll == 0){
        
        document.getElementsByClassName('navbar')[0].style.boxShadow = "0px 0px 0px 0px #0F1730",
        document.getElementsByClassName('navbar')[0].style.backdropFilter = "blur(0px)";
        

    }

    else if (animationScroll > 0){
        document.getElementsByClassName('navbar')[0].style.boxShadow = "0px 0px 34px 0px #00000044",
        document.getElementsByClassName('navbar')[0].style.backdropFilter = "blur(5px)";

    }
}


document.getElementById('about_me').addEventListener('click', ()=> {document.getElementById('aboutme_link').style.animation = '',
document.getElementById('aboutme_link').style.animation="dust 1.2s linear 0.3s";});

document.getElementById('projects').addEventListener('click', ()=> {document.getElementById('project_link').style.animation = '';
    setTimeout(()=>document.getElementById('project_link').style.animation="dust 1.2s linear 0.5s", 1);});

document.getElementById('contact').addEventListener('click', ()=> {document.getElementById('contact_link').style.animation = '';
    setTimeout(()=>document.getElementById('contact_link').style.animation="dust 1.2s linear 0.75s", 1);});

function navbarDissapear(){ 
    navbar.style.height = 'auto';
    navbar.classList.value = 'navbar';
    navlinks.classList.value = 'nav_links';
    document.body.style.overflowY = 'scroll';
}   




//giving functionality to navbar buttons[redirecting user to specific sections of the page]
//projects_navButton = document.getElementsByClassName('projects_navButton')[0];








//function for when user is reloading/refreshing website to start at scrollY(0)






