


document.onreadystatechange = function (){
    
    if(document.readyState !== 'complete'){
        
        document.getElementsByClassName("loaderLetter")[0].style.setProperty('--afterAnimation', 'preloaderAnimation 3s infinite');
        document.body.style.overflowY = 'hidden';
        document.getElementsByClassName('navbar')[0].style.display = 'none';
        document.getElementsByClassName('intro_item')[0].style.display = 'none';
        document.getElementsByClassName('page_2_section')[0].style.display = 'none';
        document.getElementsByClassName('page_3_section')[0].style.display = 'none';
        document.getElementsByClassName('section-page-4')[0].style.display = 'none';
        document.getElementsByClassName('section-page-5')[0].style.display = 'none';
        
    }


    else{
        
        

        document.getElementsByClassName("loaderLetter")[0].style.setProperty('--afterAnimation', 'preloaderAnimation 3s');
        
        

        document.getElementsByClassName("loaderLetter")[0].addEventListener('animationend', () => { 
            document.getElementsByClassName('letterContainer')[0].remove();
            document.body.style.overflowY = 'scroll';



        document.getElementsByClassName('navbar')[0].style.display = 'flex';
        document.getElementsByClassName('intro_item')[0].style.display = 'flex';
        document.getElementsByClassName('page_2_section')[0].style.display = 'flex';
        document.getElementsByClassName('page_3_section')[0].style.display = 'flex';
        document.getElementsByClassName('section-page-4')[0].style.display = 'flex';
        document.getElementsByClassName('section-page-5')[0].style.display = 'flex';

        



            
            aboutme = document.getElementById('aboutme_link');
            aboutme_rect = aboutme.getBoundingClientRect();
            
            projects = document.getElementById('project_link');
            projects_rect = projects.getBoundingClientRect();
            
            contact = document.getElementById('contact_link');
            contact_rect = contact.getBoundingClientRect();
            
            window.addEventListener('scroll', aboutme_load);
            window.addEventListener('scroll', projects_load);
            window.addEventListener('scroll', contact_load);
            

            function test_1(){



                document.getElementById('listOne').style.animation = 'navAnimation 0.6s';
                document.getElementById('listTwo').style.animation = 'navAnimation 0.8s';
                document.getElementById('listThree').style.animation = 'navAnimation 1s';
                document.getElementById('listFour').style.animation = 'navAnimation 1.2s';
            
            }
    
            test_1();
            
            function aboutme_load(){ 
            
                if (window.scrollY >= (aboutme_rect.top - aboutme_rect.height)) {
                    aboutme.style.animation = 'sectionAnimationOpacity 2.5s, sectionAnimationMovement 1s 0s';
                    aboutme.style.opacity = '100';
                }
            }
            
            
            function projects_load(){ 
                if (window.scrollY >= (projects_rect.top - projects_rect.height) + 300){
                    projects.style.animation = 'sectionAnimationOpacity 2.5s, sectionAnimationMovement 1s 0s';
                    projects.style.opacity = '100';
                }
            }
            
            function contact_load(){ 
            
                if (window.scrollY >= (contact_rect.top - (contact_rect.height * 1.5))){
                    contact.style.animation = 'sectionAnimationOpacity 2.5s, sectionAnimationMovement 1s 0s';
                    contact.style.opacity = '100';
                }
            
            }
            
            
            page_1_h2 = document.getElementById('page_1_h2');
            page_1_h3 = document.getElementById('page_1_h3');
            page_1_h31 = document.getElementById('page_1_h3.1');
            paragraph = document.getElementById('pageOneP');
            
            function pageOneh2(){ 
                
                    page_1_h2.style.animation = 'pageOneh2Animation_1 0.9s ease 0s, pageOneh2Animation 0.9s linear 0s';
            
            }
        
            function pageOneh3_(){ 
            
                
                page_1_h3.style.animation = 'pageOneh2Animation_1 0.8s ease 0s, pageOneh2Animation 0.8s linear 0s';
                page_1_h31.style.animation = 'pageOneh2Animation_1 0.7s ease 0s, pageOneh2Animation 0.8s linear 0s';
                paragraph.style.animation = 'pageOneh2Animation_1 0.6s ease 0s, pageOneh2Animation 0.8s linear 0s';
            
            }

            pageOneh2();
            pageOneh3_()
            

        } );

        
    }
    
}

