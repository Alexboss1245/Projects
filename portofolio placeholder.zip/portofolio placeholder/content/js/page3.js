//outerHTML = way of capturing both the element itself and its content / innerHTML = captures only the content withing the chosen elements
//page 3s design has to change significantly when on mobile. all media elements will have to fit inside the projects image which will hold a lower z-index
//to do that i will have to find a way to actually take the div holding the media elements and append it inside the div that holds the image
//my idea: create media query that when matching it will start a function that will move the desired div element in my chosen area (in this case in the div holding the image) 
//declare variables for project_1 
let projectOneContent = document.getElementsByClassName('project_1_content'); //div 'project_1_content', holding all media elements (buttons and text + title project)
let imageDiv_1 = document.getElementsByClassName('project_1_image'); //div holding the image of project 1
let projectOneParentContainer = document.getElementsByClassName('project_1_parent_container'); //div 'project_1_parent_container', holding the image and 'project_1_content'

//declare elements for project_2 --- keep in mind that if i will have to add way too many projects i will try and create a template that will work for all
let projectTwoContent = document.getElementsByClassName('project_2_content');
let imageDiv_2 = document.getElementsByClassName('project_2_image');
let projectTwoParentContainer = document.getElementsByClassName('project_2_parent_container')

let mediaMobile = window.matchMedia('(width < 843px)'); //media query list 

function mobilePage(e){ //apend the div elements when media query is mathching 
    if (e.matches){
        imageDiv_1[0].appendChild(projectOneContent[0]), //if media query is matching then projectOneContent (div element holding text, title description) will be appended(moved) to the images div.
        imageDiv_2[0].appendChild(projectTwoContent[0]),
        imageDiv_1[1].appendChild(projectOneContent[1]);
    }
    else {projectOneParentContainer[0].prepend(projectOneContent[0]),
        projectOneParentContainer[1].prepend(projectOneContent[1]),
        projectTwoParentContainer[0].appendChild(projectTwoContent[0]);  
    } //once the div is appended there is no way back unless i manually prepend(pre because it has to be moved in front) the div back to where it was
}

mediaMobile.addEventListener('change', () => mobilePage(mediaMobile)); //the function i created would not be invoked by itself therefore i created an event listener where every single time an object inside the media query list changes, 
//the function will start running

mobilePage(mediaMobile) //render once every load to make sure the function starts running


githubTwo = document.getElementById('git_two');
githubThree = document.getElementById('git_three');



githubTwo.addEventListener('mouseover', githubTwoToggle);
githubThree.addEventListener('mouseover', githubThreeToggle);



function githubTwoToggle(){

    githubTwo.classList.add('fa-bounce')
    githubTwo.addEventListener('mouseout', ()=>{ 
        githubTwo.classList.remove('fa-bounce')
    });
}

function githubThreeToggle(){

    githubThree.classList.add('fa-bounce')
    githubThree.addEventListener('mouseout', ()=>{ 
        githubThree.classList.remove('fa-bounce')
    });
}




githubTwo.addEventListener('click', ()=>{window.open('https://github.com/alexalx221/Projects.git', '_blank')});
githubThree.addEventListener('click', ()=>{window.open('https://github.com/alexalx221/Projects.git', '_blank')});



document.getElementsByClassName('project_1_image')[0].addEventListener('click' ,()=>{window.open('https://gladeglamp.com/', '_blank')});
document.getElementsByClassName('project_1_image')[1].addEventListener('click' ,()=>{window.open('https://aa_portofolio.com', '_blank')});
document.getElementsByClassName('project_2_image')[0].addEventListener('click' ,()=>{window.open('/content/projects/validationForm/main.html', '_blank')});


document.getElementsByClassName('project_1_image')[1].style.backgroundImage = 'url("/content/props/porto.png")';